import random

class BankAccount:
    
    _account_number = random.randint(3450, 10000)
    
    def __init__(self):
        self.account_number = BankAccount._account_number
        self.balance = 0
        BankAccount._account_number += 1
        
    def deposit(self, money):
        print(f"Added $ {money:.2f} to account number {self.account_number}")
        self.balance += money
        
    def withrawl(self, money):
        print(f"Account number {self.account_number} lacks funds, terminating withdrawl action" if self.balance <= money else f"Removed $ {money:.2f} from account number {self.account_number}")
        self.balance = (self.balance - money if self.balance >= money else self.balance)

    def __str__(self):
        return f"Account {self.account_number} has $ {self.balance:.2f}"
    
account01, account02 = BankAccount(), BankAccount()

account01.deposit(random.randint(4539, 10000)), account02.deposit(random.randint(3392, 10000))
    
print(f"{account01}\n{account02}")
    
account01.withrawl(account01.balance - account01.balance/3), account02.withrawl(account02.balance + 1)

print(f"{account01}\n{account02}")