def dup_chk(a) :
    dict1 = {}
    for i in a :
        i = i.lower()
        if i not in dict1.keys() :
            dict1[i] = 1
        else :
            dict1[i] += 1
    for key in dict1.keys() :
        if dict1[key] >= 2 :
            print(key, end= ' ')
    print('')

string_1 = "hello"
string_2 = "abcCdbB"
string_3 = "abcdefghiJKL"

dup_chk(string_1)
dup_chk(string_2)
dup_chk(string_3)