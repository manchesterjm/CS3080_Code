def char_count(a) :
    count = 0
    for i in a :
        if not i.isspace() :
            count += 1
    print(count)
    
char_count(input("Please, enter a word : "))