name = input('Please, enter your name: ')
age = int(input('Please, enter you age: '))
newage = age + 5
print(f'{name} {name} {name} {name} {name}')
print(f'Your age after 5 years: {newage}')